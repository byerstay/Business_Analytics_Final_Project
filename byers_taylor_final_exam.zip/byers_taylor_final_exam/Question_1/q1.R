library(caret)


#READING IN AND EXPLORING DATA
dataset <- read.csv('/Users/taylorbyers/Documents/Masters in Data Science/MCIS-530/Final Exam/bank-additional/bank-additional-full.csv',sep=';',header = T)
head(dataset)



#SPLITTING THE DATA
# create a list of 80% of the rows in the original dataset we can use for training
validation_index <- createDataPartition(dataset$y, p=0.80, list=FALSE)
# select 20% of the data for validation
validation <- dataset[-validation_index,]
# use the remaining 80% of data to training and testing the models
dataset <- dataset[validation_index,]



#SUMMARIZING THE DATASET
# dimensions of dataset
dim(dataset)

# list types for each attribute
sapply(dataset, class)

#list levels for each class
levels(dataset$y)

# summarize the class distribution
percentage <- prop.table(table(dataset$y)) * 100
cbind(freq=table(dataset$y), percentage=percentage)

# summarize attribute distributions
summary(dataset)



#PREPARING FOR MODELLING DATASET
# split input and output
x <- dataset[,1:20]
y <- dataset[,21]

# Run algorithms using 10-fold cross validation
control <- trainControl(method="cv", number=10)
metric <- "Accuracy"



#PRODUCING MODELS
#LDA
set.seed(7)
fit.lda <- train(y~., data=dataset, method="lda", metric=metric, trControl=control)

#CART
set.seed(7)
fit.cart <- train(y~., data=dataset, method="rpart", metric=metric, trControl=control)

#kNN
set.seed(7)
fit.knn <- train(y~., data=dataset, method="knn", metric=metric, trControl=control)

#Random Forest
set.seed(7)
fit.rf <- train(y~., data=dataset, method="rf", metric=metric, trControl=control)

#SVM
set.seed(7)
fit.svm <- train(y~., data=dataset, method="svmRadial", trControl=control)

#Summarize accuracy of models
results <- resamples(list(lda=fit.lda, cart=fit.cart, knn=fit.knn, rf=fit.rf, svm=fit.svm))
summary(results)

#Compare accuracy of models
dotplot(results)

#Summarize Best Model
print(fit.rf)

# estimate skill of RF on the validation dataset
predictions <- predict(fit.rf, validation)
confusionMatrix(predictions, validation$y)



