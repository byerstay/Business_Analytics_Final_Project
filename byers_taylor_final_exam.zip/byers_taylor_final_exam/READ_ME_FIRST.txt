READ ME FIRST

Each question on the final exam has a corresponding folder. Within each question's folder is an analysis of the question and/or the model(s) ran with any outputs that were generated. Additionally, each folder contains the data used and the R code.