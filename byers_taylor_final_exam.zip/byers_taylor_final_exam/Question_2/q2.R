#install.packages("prophet", type = "binary")
library(prophet)


#LOADING IN THE DATASET
df <- read.table('/Users/taylorbyers/Documents/Masters in Data Science/MCIS-530/Final Exam/Question_2/SeoulBikeData.csv', sep = ",", header = F)



#EXPLORING THE DATASET
head(df)


#CLEANING THE DATASET
#Renaming Columns and removing first row
#Special Note: This dataset had to be read in with headers=False, due to the nature of some characters used in the headers
#This is why some data cleaning is required from loading in the dataset
#Also must rename the columns of Date and Rented Bike Count as ds and y for prophet
df = df[-1,]
names(df)[1] <- "ds"
names(df)[2] <- "y"
names(df)[3] <- "Hour"
names(df)[4] <- "Temperature"
names(df)[5] <- "Humidity"
names(df)[6] <- "Windspeed"
names(df)[7] <- "Visibility"
names(df)[8] <- "Dew point temperature"
names(df)[9] <- "Solar radiation"
names(df)[10] <- "Rainfall"
names(df)[11] <- "Snowfall"
names(df)[12] <- "Seasons"
names(df)[13] <- "Holiday"
names(df)[14] <- "Functional Day"

#Looking at structure of Dataframe
str(df)


#Converting date column to format for prophet
df$ds <- as.Date(df$ds, format="%d/%m/%Y")
str(df)

#Summing Each Day's values for forecasting at the daily level
df_daily <- aggregate(.~ds, df, sum)



#FORECASTING WITH PROPHET FOR DAILY FORECAST
#Calling prophet to fit the model
m_daily <- prophet(df_daily)

#Constructing dataframe for prediction
future_daily <- make_future_dataframe(m_daily, periods = 365)
tail(future_daily)

#Using predict to get forecast
forecast_daily <- predict(m_daily, future_daily)
tail(forecast_daily[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])

#Plotting the forecast
plot(m_daily, forecast_daily)

#Plotting the components of forecast
prophet_plot_components(m_daily, forecast_daily)



#FORECASTING WITH PROPHET FOR HOURLY FORECAST
#Calling prophet to fit the model
m_hourly <- prophet(df)

#Constructing dataframe for prediction
future_hourly <- make_future_dataframe(m_hourly, periods = 8760, freq = 3600)
tail(future_hourly)
future_hourly$ds <- format(as.POSIXct(future_hourly$ds,format='%Y-%m-%d %H:%M:%S'), format="%Y-%m-%d")

#Using predict to get forecast
forecast_hourly <- predict(m_hourly, future_hourly)
tail(forecast_hourly[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])

#Plotting the forecast
plot(m_hourly, forecast_hourly)

#Plotting the components of forecast
prophet_plot_components(m_hourly, forecast_hourly)


